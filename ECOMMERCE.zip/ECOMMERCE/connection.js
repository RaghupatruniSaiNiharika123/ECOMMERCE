var mysql = require('mysql');

var conn = mysql.createConnection({
    host: "localhost",
    user: "surya",
    password: "1234@Surya",
    database: "niharika"  //import maindatabase.sql to your system
});

conn.connect(function(err) {
    if(err) throw err;
    console.log("Connected to niharika Database");
});

module.exports = conn;
