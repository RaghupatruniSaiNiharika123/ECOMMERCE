const express = require('express');
const bodyParser = require('body-parser');
const mysql = require('mysql');
const conn = require('./connection');
const path=require('path')
const app = express();

app.set('view engine','ejs')
app.set('views','views')

app.use(express.urlencoded({extended:false}));


app.use(express.static('public'));

app.get('/',(req,res)=>{
    const query=`(SELECT * FROM products ORDER BY id ASC LIMIT 8)
    UNION ALL
    (SELECT * FROM (SELECT * FROM products ORDER BY id DESC LIMIT 8) AS temp ORDER BY id)`;

    conn.query(query,(err,result)=>{
        if(err) console.log(err);
        const featuredProducts = result.slice(0, 8);
        const newArrivals = result.slice(8);
        res.render('index', { data:result,featuredProducts, newArrivals });
    });
});

app.get('/register',(req,res)=>{
    res.sendFile(path.join(__dirname,'/views/sign_up.html'))
}); 


// Handle registration form submission
app.post('/register', (req, res) => {
    const { username, email, password } = req.body;

    // Check if user with the same email or username already exists
    const checkIfExists = 'SELECT COUNT(*) AS count FROM users WHERE email = ? OR username = ?';
    conn.query(checkIfExists, [email, username], (err, result) => {
        if (err) {
            throw err;
        }

        if (result[0].count > 0) {
            res.send('User with the same email or username already exists.');
        } else {
            const sql = 'INSERT INTO users (username, email, password) VALUES (?, ?, ?)';
            conn.query(sql, [username, email, password], (err) => {
                if (err) {
                    throw err; 
                }
                res.redirect('/login');
            });
        }
    });
});



app.get('/login',(req,res)=>{
    res.sendFile(path.join(__dirname,'/views/login_page.html'))
});



app.post('/login', (req, res) => {
    const { usernameOrEmail, password } = req.body;

    const sql = 'SELECT * FROM users WHERE username = ? OR email = ?';
    conn.query(sql, [usernameOrEmail, usernameOrEmail], (err, result) => {
        if (err) {
            throw err;
        }

        if (result.length > 0) {
            const user = result[0];

            if (user.password === password) {
                res.render('index');
            } else {
                res.send('Invalid password');
            }
        } else {
            res.send('User not found');
        }
    });
});


app.get('/shop',(req,res)=>{
    const query=`SELECT * FROM products`;

    conn.query(query,(err,result)=>{
        if(err) console.log(err);
        res.render('shop',{data:result});
    });
})

app.get('/about',(req,res)=>{
    res.render('about')
})

app.get('/contact',(req,res)=>{
    res.render('contact')
})

app.post('/details',(req,res)=>{
    const {name,email,message} = req.body;
    const query = 'INSERT INTO details(name,email,message) VALUES (?,?,?)';
    conn.query(query,[name,email,message],(err,result)=>{
        if(err) throw err;
        
        res.redirect('/');
    });
});

app.get('/cart',(req,res)=>{
    const query2='SELECT * FROM products where id in(SELECT productId from carts)';

    conn.query(query2,(err,result)=>{
        if(err) console.log(err);
        
        res.render('cartpage',{data:result})
    })
})


app.post('/addToCart',(req,res)=>{
    const query = 'INSERT INTO carts(productId) VALUES (?)';
    conn.query(query,[req.body.id],(err,result)=>{
        if(err) throw err;
        
        res.redirect( `/shop`)

    })
})

const port = 3000;
app.listen(port,()=>{
    console.log(`the app is running on ${port}`);
});