const passwordField = document.getElementById("password");
const togglePassword = document.getElementById("toggle-password");
const confirmPasswordField = document.getElementById("confirmPassword");
const togglePassword2 = document.getElementById("toggle-password2");



togglePassword.addEventListener("click", function () {
    if (passwordField.type === "password") {
        passwordField.type = "text";
        togglePassword.innerHTML = '<ion-icon name="eye-off"></ion-icon>';
    } else {
        passwordField.type = "password";
        togglePassword.innerHTML = '<ion-icon name="eye"></ion-icon>';
    }
});

togglePassword2.addEventListener("click", function () {
    if (confirmPasswordField.type === "password") {
        confirmPasswordField.type = "text";
        togglePassword2.innerHTML = '<ion-icon name="eye-off"></ion-icon>';
    } else {
        confirmPasswordField.type = "password";
        togglePassword2.innerHTML = '<ion-icon name="eye"></ion-icon>';
    }
});